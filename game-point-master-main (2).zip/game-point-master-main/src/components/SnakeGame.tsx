import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import type { Player } from "@/hooks/useAuth";

const N = 18;
type P = { x: number; y: number };

function msLeft(last: string | null) {
  if (!last) return 0;
  return Math.max(0, 24 * 3600_000 - (Date.now() - new Date(last).getTime()));
}
function fmt(ms: number) {
  const s = Math.ceil(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return [h, m, x].map((v) => String(v).padStart(2, "0")).join(":");
}
function cssVar(name: string) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

export function SnakeGame({ player, onChange }: { player: Player; onChange: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const st = useRef({
    snake: [] as P[], dir: { x: 1, y: 0 }, next: { x: 1, y: 0 }, food: null as P | null,
    gold: null as P | null, obstacles: [] as P[], score: 0, boostUntil: 0, running: false,
    session: null as string | null, timer: 0 as unknown as ReturnType<typeof setTimeout>, lives: 0,
  });
  const [score, setScore] = useState(0);
  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState("Gotowy? Zbieraj jedzenie i unikaj przeszkód.");
  const [now, setNow] = useState(Date.now());
  const [lives, setLives] = useState(player.lives);

  useEffect(() => { if (!st.current.running) { setLives(player.lives); st.current.lives = player.lives; } }, [player.lives]);
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);

  const draw = useCallback(() => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext("2d")!; const cell = c.width / N; const s = st.current;
    ctx.fillStyle = cssVar("--card"); ctx.fillRect(0, 0, c.width, c.height);
    ctx.strokeStyle = cssVar("--border"); ctx.lineWidth = 1;
    for (let i = 1; i < N; i++) {
      ctx.beginPath(); ctx.moveTo(i * cell, 0); ctx.lineTo(i * cell, c.height); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * cell); ctx.lineTo(c.width, i * cell); ctx.stroke();
    }
    ctx.fillStyle = cssVar("--heart");
    s.obstacles.forEach((o) => { ctx.beginPath(); ctx.roundRect(o.x * cell + 3, o.y * cell + 3, cell - 6, cell - 6, 5); ctx.fill(); });
    const dot = (p: P, r: number, col: string) => {
      ctx.shadowColor = col; ctx.shadowBlur = 14; ctx.fillStyle = col;
      ctx.beginPath(); ctx.arc(p.x * cell + cell / 2, p.y * cell + cell / 2, cell * r, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
    };
    if (s.food) dot(s.food, 0.3, cssVar("--accent"));
    if (s.gold) dot(s.gold, 0.42, cssVar("--gold"));
    const prim = cssVar("--primary");
    s.snake.forEach((p, i) => {
      ctx.fillStyle = prim; ctx.globalAlpha = i === 0 ? 1 : Math.max(0.45, 1 - i * 0.03);
      if (i === 0) { ctx.shadowColor = prim; ctx.shadowBlur = 16; }
      ctx.beginPath(); ctx.roundRect(p.x * cell + 2, p.y * cell + 2, cell - 4, cell - 4, 6); ctx.fill();
      ctx.shadowBlur = 0;
    });
    ctx.globalAlpha = 1;
  }, []);

  const empty = (): P => {
    const s = st.current;
    for (let t = 0; t < 500; t++) {
      const p = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) };
      const hit = (q: P | null) => q && q.x === p.x && q.y === p.y;
      if (!s.snake.some(hit) && !s.obstacles.some(hit) && !hit(s.food) && !hit(s.gold)) return p;
    }
    return { x: 1, y: 1 };
  };

  const finish = useCallback(async () => {
    const s = st.current; s.running = false; setRunning(false); clearTimeout(s.timer);
    setStatus(`Koniec gry! Wynik: ${s.score} pkt`);
    if (s.session) {
      const { error } = await supabase.rpc("finish_game", { p_session: s.session, p_score: s.score });
      if (error) setStatus(error.message);
      s.session = null;
    }
    onChange();
  }, [onChange]);

  const tick = useCallback(async () => {
    const s = st.current; if (!s.running) return;
    s.dir = s.next;
    const h0 = s.snake[0]!; const head = { x: h0.x + s.dir.x, y: h0.y + s.dir.y };
    const crash = head.x < 0 || head.y < 0 || head.x >= N || head.y >= N ||
      s.snake.some((p) => p.x === head.x && p.y === head.y) ||
      (Date.now() > s.boostUntil && s.obstacles.some((p) => p.x === head.x && p.y === head.y));
    if (crash) {
      if (s.lives > 0 && s.session) {
        s.running = false;
        const { data } = await supabase.rpc("use_life", { p_session: s.session });
        if (data) {
          s.lives -= 1; setLives(s.lives);
          s.snake = [{ x: 9, y: 9 }, { x: 8, y: 9 }, { x: 7, y: 9 }];
          s.dir = s.next = { x: 1, y: 0 };
          s.obstacles = s.obstacles.filter((o) => o.y !== 9);
          setStatus("❤️ Użyto życia — grasz dalej!");
          draw();
          setTimeout(() => { s.running = true; tick(); }, 1200);
          return;
        }
      }
      finish(); return;
    }
    s.snake.unshift(head);
    if (s.food && head.x === s.food.x && head.y === s.food.y) {
      s.score += 1; s.food = empty();
      if (s.score % 10 === 0 && !s.gold) s.gold = empty();
      if (s.score % 25 === 0) { s.boostUntil = Date.now() + 8000; setStatus("✨ Boost! Przeszkody nie działają przez 8 s"); }
      if (s.score % 7 === 0) s.obstacles.push(empty());
    } else if (s.gold && head.x === s.gold.x && head.y === s.gold.y) {
      s.score += 3; s.gold = null; setStatus("🪙 Złoty punkt +3!");
    } else s.snake.pop();
    setScore(s.score); draw();
    s.timer = setTimeout(tick, Date.now() < s.boostUntil ? 75 : 110);
  }, [draw, finish]);

  async function start() {
    const { data, error } = await supabase.rpc("start_game");
    if (error) { setStatus(error.message); return; }
    const s = st.current;
    s.session = data as string; s.lives = player.lives;
    s.snake = [{ x: 9, y: 9 }, { x: 8, y: 9 }, { x: 7, y: 9 }];
    s.dir = s.next = { x: 1, y: 0 }; s.score = 0; s.boostUntil = 0; s.gold = null; s.food = null;
    s.obstacles = []; for (let i = 0; i < 3; i++) s.obstacles.push(empty());
    s.food = empty(); setScore(0); setStatus("Powodzenia! 🐍"); s.running = true; setRunning(true);
    onChange(); draw(); tick();
  }

  const setDir = (x: number, y: number) => {
    const s = st.current; if (!s.running) return;
    if (x === -s.dir.x && y === -s.dir.y) return; s.next = { x, y };
  };

  useEffect(() => {
    draw();
    const onKey = (e: KeyboardEvent) => {
      const m: Record<string, [number, number]> = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0] };
      const v = m[e.key]; if (v) { e.preventDefault(); setDir(...v); }
    };
    window.addEventListener("keydown", onKey);
    return () => { window.removeEventListener("keydown", onKey); clearTimeout(st.current.timer); };
  }, [draw]);

  const touch = useRef<{ x: number; y: number } | null>(null);
  const left = msLeft(player.last_game_at);
  void now;
  const canPlay = !running && (left === 0 || player.extra_games > 0);

  return (
    <section className="panel p-4 sm:p-5 space-y-4">
      <div className="grid grid-cols-3 gap-2 text-center">
        <Stat label="Wynik" value={score} cls="text-primary" />
        <Stat label="Rekord" value={player.best_score} cls="text-gold" />
        <Stat label="Życia" value={`❤️ ${lives}`} cls="text-heart" />
      </div>
      <canvas
        ref={canvasRef} width={432} height={432}
        className="w-full aspect-square rounded-xl border border-border touch-none glow"
        onTouchStart={(e) => { const t = e.touches[0]!; touch.current = { x: t.clientX, y: t.clientY }; }}
        onTouchEnd={(e) => {
          if (!touch.current) return; const t = e.changedTouches[0]!;
          const dx = t.clientX - touch.current.x, dy = t.clientY - touch.current.y;
          if (Math.max(Math.abs(dx), Math.abs(dy)) > 20) Math.abs(dx) > Math.abs(dy) ? setDir(Math.sign(dx), 0) : setDir(0, Math.sign(dy));
          touch.current = null;
        }}
      />
      <p className="text-center text-sm text-muted-foreground min-h-5">{status}</p>
      <Button variant="hero" className="w-full h-14" disabled={!canPlay} onClick={start}>
        {running ? "GRASZ…" : left === 0 ? "ZAGRAJ" : player.extra_games > 0 ? `ZAGRAJ (dodatkowa gra · ${player.extra_games})` : `KOLEJNA GRA ZA ${fmt(left)}`}
      </Button>
      <div className="grid grid-cols-3 gap-2 max-w-48 mx-auto sm:hidden">
        <span /><Button variant="chip" onClick={() => setDir(0, -1)}>▲</Button><span />
        <Button variant="chip" onClick={() => setDir(-1, 0)}>◀</Button>
        <Button variant="chip" onClick={() => setDir(0, 1)}>▼</Button>
        <Button variant="chip" onClick={() => setDir(1, 0)}>▶</Button>
      </div>
      <p className="text-center text-xs text-muted-foreground">Strzałki / WASD lub przesuwaj palcem po planszy.</p>
    </section>
  );
}

function Stat({ label, value, cls }: { label: string; value: React.ReactNode; cls: string }) {
  return (
    <div className="rounded-xl bg-secondary py-2">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={`font-display text-xl ${cls}`}>{value}</div>
    </div>
  );
}
