import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AuthCard } from "@/components/AuthCard";
import { SnakeGame } from "@/components/SnakeGame";
import { Ranking } from "@/components/Ranking";
import { AdminPanel } from "@/components/AdminPanel";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Snake Arena — jedna gra dziennie" },
      { name: "description", content: "Neonowy Snake: jedna gra co 24h, ranking graczy, dodatkowe życia i gry od administratora." },
      { property: "og:title", content: "Snake Arena — jedna gra dziennie" },
      { property: "og:description", content: "Zagraj raz dziennie, zbieraj punkty i walcz o szczyt rankingu." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Tab = "game" | "info" | "admin";

function Index() {
  const { player, isAdmin, ready, refresh, user } = useAuth();
  const [tab, setTab] = useState<Tab>("game");
  const [rk, setRk] = useState(0);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const onChange = () => { refresh(); setRk((k) => k + 1); };

  return (
    <main className="mx-auto max-w-xl px-4 py-6 space-y-5">
      <Toaster />
      <header className="text-center space-y-1">
        <h1 className="font-display text-4xl sm:text-5xl text-primary text-glow">SNAKE ARENA</h1>
        <p className="text-muted-foreground text-sm">Jedna gra co 24 godziny. Graj mądrze.</p>
      </header>

      {mounted && ready && user && (
        <nav className="flex gap-2">
          <Button variant={tab === "game" ? "default" : "chip"} className="flex-1" onClick={() => setTab("game")}>🐍 Gra</Button>
          <Button variant={tab === "info" ? "default" : "chip"} className="flex-1" onClick={() => setTab("info")}>ℹ️ Zasady</Button>
          {isAdmin && <Button variant={tab === "admin" ? "default" : "chip"} className="flex-1" onClick={() => setTab("admin")}>👑 Admin</Button>}
        </nav>
      )}

      {!mounted || !ready ? (
        <p className="text-center text-muted-foreground">Ładowanie…</p>
      ) : !user ? (
        <AuthCard />
      ) : !player ? (
        <p className="text-center text-muted-foreground">Nie znaleziono konta gracza.</p>
      ) : tab === "game" ? (
        <>
          <div className="flex items-center justify-between panel px-4 py-3">
            <div>
              <div className="text-xs text-muted-foreground">Grasz jako</div>
              <div className="font-display text-lg">{player.nick}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground">Twoje punkty</div>
              <div className="font-display text-lg text-primary">{player.points}</div>
            </div>
          </div>
          <SnakeGame player={player} onChange={onChange} />
          <Ranking refreshKey={rk} />
        </>
      ) : tab === "info" ? (
        <section className="panel p-5 space-y-3 text-sm leading-relaxed">
          <h2 className="font-display text-xl">Zasady</h2>
          <p>🎮 Każdy gracz ma <b>jedną grę co 24 godziny</b>. Konto startuje z 0 punktów.</p>
          <p>🍋 Jedzenie: +1 pkt · 🪙 złoty punkt: +3 pkt · ✨ co 25 pkt boost — przeszkody przestają działać na 8 s.</p>
          <p>❤️ Życie pozwala kontynuować grę po zderzeniu. Życia i dodatkowe gry przyznaje administrator.</p>
          <p>🔒 Jedno konto = jeden nick. Nicku nie da się zmienić.</p>
        </section>
      ) : (
        isAdmin && <AdminPanel />
      )}

      {mounted && user && (
        <div className="text-center">
          <Button variant="link" onClick={() => supabase.auth.signOut()}>Wyloguj</Button>
        </div>
      )}
    </main>
  );
}
